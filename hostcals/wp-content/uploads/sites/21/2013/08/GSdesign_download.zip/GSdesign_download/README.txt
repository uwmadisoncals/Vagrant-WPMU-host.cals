Package: GSdesign
Title: Breeding program design with genomic selection
Version: 0.2
Date: 2013-08-05
Author: Jeffrey Endelman
Maintainer: Jeffrey Endelman <endelman@wisc.edu>
Depends: R (>= 2.14)
Suggests: parallel
Description: This package contains software to optimize breeding programs for maximum genetic gain.
License: GPL-3

The GNU Scientific Library (http://www.gnu.org/software/gsl/) must be present for this R package to be installed.
To install on a UNIX-compliant system (Linux, MacOS, Cygwin), try the following:

R CMD INSTALL GSdesign_0.2.tar.gz

If R complains about not finding GSL, you may need to modify the Makevars file in the src subdirectory of the package.

Alternatively, to use the package for Rmean only (not Rmax), you can unzip and use the scripts (Response.R, maximize.gain.R) in the R subdirectory.